#ifndef __crc32_h
#define __crc32_h

extern unsigned long crc32(unsigned long crc, const unsigned char *buf,
			   int len);
#endif
